
# coding: utf-8

# In[2]:


# https://www.kaggle.com/pmarcelino/comprehensive-data-exploration-with-python

# 1.	Understand the problem. We'll look at each variable and do a philosophical analysis about their meaning and importance for this problem.
# 2.	Univariable study. We'll just focus on the dependent variable ('SalePrice') and try to know a little bit more about it.
# 3.	Multivariate study. We'll try to understand how the dependent variable and independent variables relate.
# 4.	Basic cleaning. We'll clean the dataset and handle the missing data, outliers and categorical variables.
# 5.	Test assumptions. We'll check if our data meets the assumptions required by most multivariate techniques.


# In[3]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:


df = pd.read_csv('train.csv')


# In[5]:


df.describe()


# In[6]:


df.columns


# In[7]:


# 1. So... What can we expect?
# In order to understand our data, we can look at each variable and try to understand their meaning and relevance to this problem. I know this is time-consuming, but it will give us the flavour of our dataset.

# In order to have some discipline in our analysis, we can create an Excel spreadsheet with the following columns:

# Variable - Variable name.
# Type - Identification of the variables' type. There are two possible values for this field: 'numerical' or 'categorical'. By 'numerical' we mean variables for which the values are numbers, and by 'categorical' we mean variables for which the values are categories.
# Segment - Identification of the variables' segment. We can define three possible segments: building, space or location. When we say 'building', we mean a variable that relates to the physical characteristics of the building (e.g. 'OverallQual'). When we say 'space', we mean a variable that reports space properties of the house (e.g. 'TotalBsmtSF'). Finally, when we say a 'location', we mean a variable that gives information about the place where the house is located (e.g. 'Neighborhood').
# Expectation - Our expectation about the variable influence in 'SalePrice'. We can use a categorical scale with 'High', 'Medium' and 'Low' as possible values.
# Conclusion - Our conclusions about the importance of the variable, after we give a quick look at the data. We can keep with the same categorical scale as in 'Expectation'.
# Comments - Any general comments that occured to us.
# While 'Type' and 'Segment' is just for possible future reference, the column 'Expectation' is important because it will help us develop a 'sixth sense'. To fill this column, we should read the description of all the variables and, one by one, ask ourselves:

# Do we think about this variable when we are buying a house? (e.g. When we think about the house of our dreams, do we care about its 'Masonry veneer type'?).
# If so, how important would this variable be? (e.g. What is the impact of having 'Excellent' material on the exterior instead of 'Poor'? And of having 'Excellent' instead of 'Good'?).
# Is this information already described in any other variable? (e.g. If 'LandContour' gives the flatness of the property, do we really need to know the 'LandSlope'?).
# After this daunting exercise, we can filter the spreadsheet and look carefully to the variables with 'High' 'Expectation'. Then, we can rush into some scatter plots between those variables and 'SalePrice', filling in the 'Conclusion' column which is just the correction of our expectations.

# I went through this process and concluded that the following variables can play an important role in this problem:

# OverallQual (which is a variable that I don't like because I don't know how it was computed; a funny exercise would be to predict 'OverallQual' using all the other variables available).
# YearBuilt.
# TotalBsmtSF.
# GrLivArea.
# I ended up with two 'building' variables ('OverallQual' and 'YearBuilt') and two 'space' variables ('TotalBsmtSF' and 'GrLivArea'). This might be a little bit unexpected as it goes against the real estate mantra that all that matters is 'location, location and location'. It is possible that this quick data examination process was a bit harsh for categorical variables. For example, I expected the 'Neigborhood' variable to be more relevant, but after the data examination I ended up excluding it. Maybe this is related to the use of scatter plots instead of boxplots, which are more suitable for categorical variables visualization. The way we visualize data often influences our conclusions.

# However, the main point of this exercise was to think a little about our data and expectactions, so I think we achieved our goal. Now it's time for 'a little less conversation, a little more action please'. Let's shake it!


# In[8]:


# 2. First things first: analysing 'SalePrice'¶
# 'SalePrice' is the reason of our quest. It's like when we're going to a party. We always have a reason to be there. Usually, women are that reason. (disclaimer: adapt it to men, dancing or alcohol, according to your preferences)

# Using the women analogy, let's build a little story, the story of 'How we met 'SalePrice''.

# Everything started in our Kaggle party, when we were looking for a dance partner. After a while searching in the dance floor, we saw a girl, near the bar, using dance shoes. That's a sign that she's there to dance. We spend much time doing predictive modelling and participating in analytics competitions, so talking with girls is not one of our super powers. Even so, we gave it a try:

# 'Hi, I'm Kaggly! And you? 'SalePrice'? What a beautiful name! You know 'SalePrice', could you give me some data about you? I just developed a model to calculate the probability of a successful relationship between two people. I'd like to apply it to us!'


# In[9]:


df['SalePrice'].describe()


# In[10]:


sns.distplot(df['SalePrice'])


# In[11]:


# # Deviate from the normal distribution.
# # Have appreciable positive skewness.
# # Show peakedness.


# Skewness is usually described as a measure of a dataset’s symmetry – or lack of symmetry.   A perfectly symmetrical data set will have a skewness of 0.   The normal distribution has a skewness of 0. 
# kurtosis is all about the tails of the distribution – not the peakedness or flatness.  It measures the tail-heaviness of the distribution
# The kurtosis decreases as the tails become lighter.  It increases as the tails become heavier


# In[12]:


# sckeness and kurtosis
print ("skeness is : %f" % df['SalePrice'].skew())
print ("Kurtosis is : %f" % df['SalePrice'].kurt())


# In[13]:


#scatter plot SalePrice vs GrLivArea
df['GrLivArea'].head()
df['GrLivArea'].describe()

data1 = pd.concat([df['SalePrice'],df['GrLivArea']] , axis=1)
data1.plot.scatter(x='SalePrice', y='GrLivArea') # linear relationship.


# In[14]:


#total bsment vs salesprice
#df['TotalBsmtSF']
data2 = pd.concat([df['TotalBsmtSF'], df['SalePrice']], axis=1)
data2.plot.scatter(x='SalePrice', y='TotalBsmtSF')


# In[15]:


# OverallQual vs SalePrice

data3 = pd.concat([df['OverallQual'], df['SalePrice']], axis=1)
data3.plot.scatter(x='SalePrice', y='OverallQual')


# In[23]:


fig = sns.boxplot(x="OverallQual", y="SalePrice", data=data3)
fig.axis(ymin = 0, ymax = 800000)


# f, ax = plt.subplots(figsize=(8, 6))
# fig = sns.boxplot(x="SalePrice", y="OverallQual", data=data3)
# fig.axis(ymin=0, ymax=800000);

# 'GrLivArea' and 'TotalBsmtSF' seem to be linearly related with 'SalePrice'. Both relationships are positive, which means that as one variable increases, the other also increases. In the case of 'TotalBsmtSF', we can see that the slope of the linear relationship is particularly high.
# 'OverallQual' and 'YearBuilt' also seem to be related with 'SalePrice'. The relationship seems to be stronger in the case of 'OverallQual', where the box plot shows how sales prices increase with the overall quality.

# # create correlation matrix to analyze all other variables

# Correlation matrix (heatmap style).
# 'SalePrice' correlation matrix (zoomed heatmap style).
# Scatter plots between the most correlated variables (move like Jagger style).


# correlation matrix - heat map 
corrmat = df.corr()
f, ax=plt.subplots(figsize=(15,15))
sns.heatmap(corrmat, annot= False, vmin = 0, vmax=1, square=True, cmap="YlGnBu")

# At first sight, there are two red colored squares that get my attention. The first one refers to the 'TotalBsmtSF' and '1stFlrSF' variables, and the second one refers to the 'GarageX' variables. Both cases show how significant the correlation is between these variables. Actually, this correlation is so strong that it can indicate a situation of multicollinearity. If we think about these variables, we can conclude that they give almost the same information so multicollinearity really occurs. Heatmaps are great to detect this kind of situations and in problems dominated by feature selection, like ours, they are an essential tool.

# Another thing that got my attention was the 'SalePrice' correlations. We can see our well-known 'GrLivArea', 'TotalBsmtSF', and 'OverallQual' saying a big 'Hi!', but we can also see many other variables that should be taken into account. That's what we will do next.


#SalePrice heat map Zoomed heatmap 
k = 10 # columns
cols = corrmat.nlargest(k, 'SalePrice')['SalePrice'].index
cols
cm = np.corrcoef(df[cols].values.T)
cm
sns.set(font_scale=1.25)
ZoomeHP = sns.heatmap(cm, annot=True, yticklabels=cols.values, xticklabels=cols.values)


# 'OverallQual', 'GrLivArea' and 'TotalBsmtSF' are strongly correlated with 'SalePrice'. Check!
# 'GarageCars' and 'GarageArea' are also some of the most strongly correlated variables. However, as we discussed in the last sub-point, the number of cars that fit into the garage is a consequence of the garage area. 'GarageCars' and 'GarageArea' are like twin brothers. You'll never be able to distinguish them. Therefore, we just need one of these variables in our analysis (we can keep 'GarageCars' since its correlation with 'SalePrice' is higher).
# 'TotalBsmtSF' and '1stFloor' also seem to be twin brothers. We can keep 'TotalBsmtSF' just to say that our first guess was right (re-read 'So... What can we expect?').
# 'FullBath'?? Really?
# 'TotRmsAbvGrd' and 'GrLivArea', twin brothers again. Is this dataset from Chernobyl?
# Ah... 'YearBuilt'... It seems that 'YearBuilt' is slightly correlated with 'SalePrice'. Honestly, it scares me to think about 'YearBuilt' because I start feeling that we should do a little bit of time-series analysis to get this right. I'll leave this as a homework for you.




#scatter plot

sns.set()
cols = ['SalePrice', 'OverallQual', 'GrLivArea', 'GarageCars', 'TotalBsmtSF', 'FullBath', 'YearBuilt']
sns.pairplot(df[cols])
plt.show()


# One of the figures we may find interesting is the one between 'TotalBsmtSF' and 'GrLiveArea'. In this figure we can see the dots drawing a linear line, which almost acts like a border. It totally makes sense that the majority of the dots stay below that line. Basement areas can be equal to the above ground living area, but it is not expected a basement area bigger than the above ground living area (unless you're trying to buy a bunker).

# The plot concerning 'SalePrice' and 'YearBuilt' can also make us think. In the bottom of the 'dots cloud', we see what almost appears to be a shy exponential function (be creative). We can also see this same tendency in the upper limit of the 'dots cloud' (be even more creative). Also, notice how the set of dots regarding the last years tend to stay above this limit (I just wanted to say that prices are increasing faster now).



# 4. Missing data
# Important questions when thinking about missing data:

# How prevalent is the missing data?
# Is missing data random or does it have a pattern?
# The answer to these questions is important for practical reasons because missing data can imply a reduction of the sample size. This can prevent us from proceeding with the analysis. Moreover, from a substantive perspective, we need to ensure that the missing data process is not biased and hidding an inconvenient truth.



#missing data 
total = df.isnull().sum().sort_values(ascending=False)
percentage = ((df.isnull().sum()/df.isnull().count())*100).sort_values(ascending=False)
missing_data = pd.concat([total, percentage], axis = 1, keys=['Total', 'Percentage'])
missing_data.head(20)


# We'll consider that when more than 15% of the data is missing, we should delete the corresponding variable and pretend it never existed. This means that we will not try any trick to fill the missing data in these cases. According to this, there is a set of variables (e.g. 'PoolQC', 'MiscFeature', 'Alley', etc.) that we should delete. The point is: will we miss this data? I don't think so. None of these variables seem to be very important, since most of them are not aspects in which we think about when buying a house (maybe that's the reason why data is missing?). Moreover, looking closer at the variables, we could say that variables like 'PoolQC', 'MiscFeature' and 'FireplaceQu' are strong candidates for outliers, so we'll be happy to delete them.

# In what concerns the remaining cases, we can see that 'GarageX' variables have the same number of missing data. I bet missing data refers to the same set of observations (although I will not check it; it's just 5% and we should not spend 20 in5 problems). Since the most important information regarding garages is expressed by 'GarageCars' and considering that we are just talking about 5% of missing data, I'll delete the mentioned 'GarageX' variables. The same logic applies to 'BsmtX' variables.

# Regarding 'MasVnrArea' and 'MasVnrType', we can consider that these variables are not essential. Furthermore, they have a strong correlation with 'YearBuilt' and 'OverallQual' which are already considered. Thus, we will not lose information if we delete 'MasVnrArea' and 'MasVnrType'.

# Finally, we have one missing observation in 'Electrical'. Since it is just one observation, we'll delete this observation and keep the variable.

# In summary, to handle missing data, we'll delete all the variables with missing data, except the variable 'Electrical'. In 'Electrical' we'll just delete the observation with missing data.

#dealing with missing data
df_train = df
df_train = df_train.drop(missing_data[missing_data['Total']>1].index, axis=1)
df_train = df_train.drop(df_train.loc[df_train['Electrical'].isnull()].index)
df_train.isnull().sum().max() #just checking that there's no missing data missing...




# Out liars!
# Outliers is also something that we should be aware of. Why? Because outliers can markedly affect our models and can be a valuable source of information, providing us insights about specific behaviours.

# Outliers is a complex subject and it deserves more attention. Here, we'll just do a quick analysis through the standard deviation of 'SalePrice' and a set of scatter plots.


# Univariate analysis
# The primary concern here is to establish a threshold that defines an observation as an outlier. To do so, we'll standardize the data. In this context, data standardization means converting data values to have mean of 0 and a standard deviation of 1.

#standardizing data
scaled_saleprice = StandardScaler().fit_transform(df_train['SalePrice'][:,np.newaxis]);
low_range = scaled_saleprice[scaled_saleprice[:,0].argsort()][:10]
high_range = scaled_saleprice[scaled_saleprice[:,0].argsort()][ -10:]
print('low_range')
print(low_range)
print('high_range')
print(high_range)


# How 'SalePrice' looks with her new clothes:

# Low range values are similar and not too far from 0.
# High range values are far from 0 and the 7.something values are really out of range.
# For now, we'll not consider any of these values as an outlier but we should be careful with those two 7.something values.

#standardizing data
from sklearn.preprocessing import StandardScaler
ss = StandardScaler()
scaled_saleprice = StandardScaler().fit(df_train['SalePrice'][:,np.newaxis]);
low_range = scaled_saleprice[scaled_saleprice[:,0].argsort()][:10]
high_range = scaled_saleprice[scaled_saleprice[:,0].argsort()][ -10:]

# Bivariate analysis¶
# We already know the following scatter plots by heart. However, when we look to things from a new perspective, there's always something to discover. As Alan Kay said, 'a change in perspective is worth 80 IQ points'.


df_train.plot.scatter(x='SalePrice', y='GrLivArea') # linear relationship.

# What has been revealed:

# The two values with bigger 'GrLivArea' seem strange and they are not following the crowd. We can speculate why this is happening. Maybe they refer to agricultural area and that could explain the low price. I'm not sure about this but I'm quite confident that these two points are not representative of the typical case. Therefore, we'll define them as outliers and delete them.
# The two observations in the top of the plot are those 7.something observations that we said we should be careful about. They look like two special cases, however they seem to be following the trend. For that reason, we will keep them.

#deleting points
df_train.sort_values(by='GrLivArea', ascending = False)[:2]
df_train = df_train.drop(df_train[df_train['Id'] == 1299].index)
df_train = df_train.drop(df_train[df_train['Id'] == 524].index)

df_train.sort_values(by='GrLivArea', ascending = False)[:2]


#bivariate analysis saleprice/grlivarea

df_train.plot.scatter(x='TotalBsmtSF', y='SalePrice');


# We can feel tempted to eliminate some observations (e.g. TotalBsmtSF > 3000) but I suppose it's not worth it. We can live with that, so we'll not do anything.
# I feel Randian now. Who is 'SalePrice'?

# The answer to this question lies in testing for the assumptions underlying the statistical bases for multivariate analysis. We already did some data cleaning and discovered a lot about 'SalePrice'. Now it's time to go deep and understand how 'SalePrice' complies with the statistical assumptions that enables us to apply multivariate techniques.

# Normality - When we talk about normality what we mean is that the data should look like a normal distribution. This is important because several statistic tests rely on this (e.g. t-statistics). In this exercise we'll just check univariate normality for 'SalePrice' (which is a limited approach). Remember that univariate normality doesn't ensure multivariate normality (which is what we would like to have), but it helps. Another detail to take into account is that in big samples (>200 observations) normality is not such an issue. However, if we solve normality, we avoid a lot of other problems (e.g. heteroscedacity) so that's the main reason why we are doing this analysis.

# Homoscedasticity - I just hope I wrote it right. Homoscedasticity refers to the 'assumption that dependent variable(s) exhibit equal levels of variance across the range of predictor variable(s)' (Hair et al., 2013). Homoscedasticity is desirable because we want the error term to be the same across all values of the independent variables.

# Linearity- The most common way to assess linearity is to examine scatter plots and search for linear patterns. If patterns are not linear, it would be worthwhile to explore data transformations. However, we'll not get into this because most of the scatter plots we've seen appear to have linear relationships.

# Absence of correlated errors - Correlated errors, like the definition suggests, happen when one error is correlated to another. For instance, if one positive error makes a negative error systematically, it means that there's a relationship between these variables. This occurs often in time series, where some patterns are time related. We'll also not get into this. However, if you detect something, try to add a variable that can explain the effect you're getting. That's the most common solution for correlated errors.


# In the search for normality
# The point here is to test 'SalePrice' in a very lean way. We'll do this paying attention to:

# Histogram - Kurtosis and skewness.
# Normal probability plot - Data distribution should closely follow the diagonal that represents the normal distribution.

sns.distplot(df_train['SalePrice'], kde = True, fit=norm)

stats.probplot(df_train['SalePrice'], plot =plt)


# positve sckeness solved by log transformation
# Ok, 'SalePrice' is not normal. It shows 'peakedness', positive skewness and does not follow the diagonal line.

# But everything's not lost. A simple data transformation can solve the problem. This is one of the awesome things you can learn in statistical books: in case of positive skewness, log transformations usually works well. When I discovered this, I felt like an Hogwarts' student discovering a new cool spell.


df_train['SalePrice']=np.log(df_train['SalePrice'])

#checking transformed sale price
sns.distplot(df_train['SalePrice'], kde = True, fit=norm)

stats.probplot(df_train['SalePrice'], plot=plt)


#check GrLivArea
sns.distplot(df_train['GrLivArea'], kde=True, fit=norm)

#Prob plot GrLivArea
stats.probplot(df_train['GrLivArea'], plot=plt)

#resolve sckenwss
df_train['GrLivArea']= np.log(df_train['GrLivArea'])

sns.distplot(df_train['GrLivArea'], kde=True, fit=norm)

stats.probplot(df_train['GrLivArea'], plot=plt)


#histogram and normal probability plot
sns.distplot(df_train['TotalBsmtSF'], fit=norm);
fig = plt.figure()
res = stats.probplot(df_train['TotalBsmtSF'], plot=plt)

# Ok, now we are dealing with the big boss. What do we have here?

# Something that, in general, presents skewness.
# A significant number of observations with value zero (houses without basement).
# A big problem because the value zero doesn't allow us to do log transformations.
# To apply a log transformation here, we'll create a variable that can get the effect of having or not having basement (binary variable). Then, we'll do a log transformation to all the non-zero observations, ignoring those with value zero. This way we can transform data, without losing the effect of having or not basement.

# I'm not sure if this approach is correct. It just seemed right to me. That's what I call 'high risk engineering'.

#create column for new variable (one is enough because it's a binary categorical feature)
#if area>0 it gets 1, for area==0 it gets 0
df_train['HasBsmt'] = pd.Series(len(df_train['TotalBsmtSF']), index = df_train.index)
df_train['HasBsmt'].isnull().count()
df_train['Hasbsmt'] = 0
df_train['Hasbsmt']
#df_train['HasBsmt'] = 

