
# coding: utf-8

# In[18]:


# https://www.kaggle.com/pmarcelino/comprehensive-data-exploration-with-python

# 1.	Understand the problem. We'll look at each variable and do a philosophical analysis about their meaning and importance for this problem.
# 2.	Univariable study. We'll just focus on the dependent variable ('SalePrice') and try to know a little bit more about it.
# 3.	Multivariate study. We'll try to understand how the dependent variable and independent variables relate.
# 4.	Basic cleaning. We'll clean the dataset and handle the missing data, outliers and categorical variables.
# 5.	Test assumptions. We'll check if our data meets the assumptions required by most multivariate techniques.


# In[19]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import norm
from sklearn.preprocessing import StandardScaler
from scipy import stats
import warnings
warnings.filterwarnings('ignore')
get_ipython().run_line_magic('matplotlib', 'inline')


# In[20]:


df = pd.read_csv('train.csv')


# In[21]:


df.describe()


# In[22]:


df.columns


# In[23]:


# 1. So... What can we expect?
# In order to understand our data, we can look at each variable and try to understand their meaning and relevance to this problem. I know this is time-consuming, but it will give us the flavour of our dataset.

# In order to have some discipline in our analysis, we can create an Excel spreadsheet with the following columns:

# Variable - Variable name.
# Type - Identification of the variables' type. There are two possible values for this field: 'numerical' or 'categorical'. By 'numerical' we mean variables for which the values are numbers, and by 'categorical' we mean variables for which the values are categories.
# Segment - Identification of the variables' segment. We can define three possible segments: building, space or location. When we say 'building', we mean a variable that relates to the physical characteristics of the building (e.g. 'OverallQual'). When we say 'space', we mean a variable that reports space properties of the house (e.g. 'TotalBsmtSF'). Finally, when we say a 'location', we mean a variable that gives information about the place where the house is located (e.g. 'Neighborhood').
# Expectation - Our expectation about the variable influence in 'SalePrice'. We can use a categorical scale with 'High', 'Medium' and 'Low' as possible values.
# Conclusion - Our conclusions about the importance of the variable, after we give a quick look at the data. We can keep with the same categorical scale as in 'Expectation'.
# Comments - Any general comments that occured to us.
# While 'Type' and 'Segment' is just for possible future reference, the column 'Expectation' is important because it will help us develop a 'sixth sense'. To fill this column, we should read the description of all the variables and, one by one, ask ourselves:

# Do we think about this variable when we are buying a house? (e.g. When we think about the house of our dreams, do we care about its 'Masonry veneer type'?).
# If so, how important would this variable be? (e.g. What is the impact of having 'Excellent' material on the exterior instead of 'Poor'? And of having 'Excellent' instead of 'Good'?).
# Is this information already described in any other variable? (e.g. If 'LandContour' gives the flatness of the property, do we really need to know the 'LandSlope'?).
# After this daunting exercise, we can filter the spreadsheet and look carefully to the variables with 'High' 'Expectation'. Then, we can rush into some scatter plots between those variables and 'SalePrice', filling in the 'Conclusion' column which is just the correction of our expectations.

# I went through this process and concluded that the following variables can play an important role in this problem:

# OverallQual (which is a variable that I don't like because I don't know how it was computed; a funny exercise would be to predict 'OverallQual' using all the other variables available).
# YearBuilt.
# TotalBsmtSF.
# GrLivArea.
# I ended up with two 'building' variables ('OverallQual' and 'YearBuilt') and two 'space' variables ('TotalBsmtSF' and 'GrLivArea'). This might be a little bit unexpected as it goes against the real estate mantra that all that matters is 'location, location and location'. It is possible that this quick data examination process was a bit harsh for categorical variables. For example, I expected the 'Neigborhood' variable to be more relevant, but after the data examination I ended up excluding it. Maybe this is related to the use of scatter plots instead of boxplots, which are more suitable for categorical variables visualization. The way we visualize data often influences our conclusions.

# However, the main point of this exercise was to think a little about our data and expectactions, so I think we achieved our goal. Now it's time for 'a little less conversation, a little more action please'. Let's shake it!


# In[24]:


# 2. First things first: analysing 'SalePrice'¶
# 'SalePrice' is the reason of our quest. It's like when we're going to a party. We always have a reason to be there. Usually, women are that reason. (disclaimer: adapt it to men, dancing or alcohol, according to your preferences)

# Using the women analogy, let's build a little story, the story of 'How we met 'SalePrice''.

# Everything started in our Kaggle party, when we were looking for a dance partner. After a while searching in the dance floor, we saw a girl, near the bar, using dance shoes. That's a sign that she's there to dance. We spend much time doing predictive modelling and participating in analytics competitions, so talking with girls is not one of our super powers. Even so, we gave it a try:

# 'Hi, I'm Kaggly! And you? 'SalePrice'? What a beautiful name! You know 'SalePrice', could you give me some data about you? I just developed a model to calculate the probability of a successful relationship between two people. I'd like to apply it to us!'


# In[25]:


df['SalePrice'].describe()


# In[26]:


sns.distplot(df['SalePrice'])


# In[27]:


# # Deviate from the normal distribution.
# # Have appreciable positive skewness.
# # Show peakedness.


# Skewness is usually described as a measure of a dataset’s symmetry – or lack of symmetry.   A perfectly symmetrical data set will have a skewness of 0.   The normal distribution has a skewness of 0. 
# kurtosis is all about the tails of the distribution – not the peakedness or flatness.  It measures the tail-heaviness of the distribution
# The kurtosis decreases as the tails become lighter.  It increases as the tails become heavier


# In[28]:


# sckeness and kurtosis
print ("skeness is : %f" % df['SalePrice'].skew())
print ("Kurtosis is : %f" % df['SalePrice'].kurt())


# In[29]:


#scatter plot SalePrice vs GrLivArea
df['GrLivArea'].head()
df['GrLivArea'].describe()

data1 = pd.concat([df['SalePrice'],df['GrLivArea']] , axis=1)
data1.plot.scatter(x='SalePrice', y='GrLivArea') # linear relationship.


# In[41]:


#total bsment vs salesprice
#df['TotalBsmtSF']
data2 = pd.concat([df['TotalBsmtSF'], df['SalePrice']], axis=1)
data2.plot.scatter(x='SalePrice', y='TotalBsmtSF')


# In[51]:


# OverallQual vs SalePrice

data3 = pd.concat([df['OverallQual'], df['SalePrice']], axis=1)
data3.plot.scatter(x='SalePrice', y='OverallQual')


# In[54]:


sns.boxplot(x="SalePrice", y="OverallQual", data=data3)

